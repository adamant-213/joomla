<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_helloworld
 */

defined('_JEXEC') or die;

// Load the module parameters (from XML)
$message = $params->get('message', 'Hello, Joomla World!');

// Load the layout file (tmpl/default.php)
require JModuleHelper::getLayoutPath('mod_helloworld');
