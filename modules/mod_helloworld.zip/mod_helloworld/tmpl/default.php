<?php
/**
 * @package     Joomla.Site
 * @subpackage  mod_helloworld
 */

defined('_JEXEC') or die;
?>

<div class="mod-helloworld">
    <h3><?php echo htmlspecialchars($params->get('message')); ?></h3>
</div>
